
This repository includes my answers to the excercises "An Introduction to Statistical Learning with Applications in R".

Original ebook and relating documents can be found here:

http://www-bcf.usc.edu/~gareth/ISL/
